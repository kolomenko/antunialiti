#!/bin/bash
pas="admin"
usr="1278qaz"
for ip in $(cat /root/clouddrive/oxy-vm.txt)
do
sshpass -p "$pas" ssh -o StrictHostKeychecking=no $usr@$ip "bash -s" < /root/clouddrive/3proxy.bash $pas &
done