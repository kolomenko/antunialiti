#!/bin/bash
for region in $(cat /root/clouddrive/region.txt)
do
  azure group delete -n $region-oxy &
done