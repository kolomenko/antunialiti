#!/bin/bash
function general() {
JOBS_COUNTER=0
MAX_CHILDREN=100 # потоки
MY_PID=$$
usr=""
pas=""
sys="debian"
size="Standard_B1s" 
for region in $(cat /root/clouddrive/region.txt)
do
JOBS_COUNTER=$((`ps ax -Ao ppid | grep $MY_PID | wc -l`))
while [ $JOBS_COUNTER -ge $MAX_CHILDREN ]
do
JOBS_COUNTER=$((`ps ax -Ao ppid | grep $MY_PID | wc -l`))
sleep 1's'
done
#
vnet="$region-oxy-vnet" && subnet="$region-oxy-subnet" && vm="$region-oxy" && nsg="$region-oxy-nsg" && nic="$region-nic" && rg="$region-oxy" && az group create -l $region -n $rg && az network vnet create -g $rg -n $vnet --address-prefix 12.0.0.0/24 -l $region --subnet-name $subnet --subnet-prefix 12.0.0.0/24 && qwe=$(az network public-ip create -g $rg -l $region -n oxy-conect-ip --allocation-method Static) && asd=$(az network public-ip create -g $rg -l $region -n worker-conect-ip --allocation-method Static) && echo $qwe >> /root/clouddrive/oxy-vm.txt && echo $asd >> /root/clouddrive/worker-vm.txt && az network nsg create -g $rg -l $region -n $nsg && az network nsg rule create -g $rg --nsg-name $nsg -n all --access Allow --protocol Tcp --direction Inbound --priority 100 --source-address-prefix "*" --source-port-range "*" --destination-address-prefix "*" --destination-port-range "*" && az network nsg rule create -g $rg --nsg-name $nsg -n all123 --access Allow --protocol Tcp --direction Outbound --priority 100 --source-address-prefix "*" --source-port-range "*" --destination-address-prefix "*" --destination-port-range "*" && az network nic create -g $rg -l $region -n $nic --vnet-name $vnet --subnet $subnet --private-ip-address 12.0.0.4 --public-ip-address oxy-conect-ip --network-security-group $nsg && az vm create -n $rg -g $rg -l $region --size $size --nics $nic --image $sys --admin-username $usr --admin-password $pas &
done
#
echo Finishing children ...
#
while [ $JOBS_COUNTER -gt 1 ]
do
JOBS_COUNTER=$((`ps ax -Ao ppid | grep $MY_PID | wc -l`))
echo Jobs counter: $JOBS_COUNTER
sleep 1's'
done
size="Standard_F1s" 
for region in japaneast brazilsouth westindia southindia koreasouth
do
vnet="$region-oxy-vnet" && subnet="$region-oxy-subnet" && vm="$region-oxy" && nsg="$region-oxy-nsg" && nic="$region-nic" && rg="$region-oxy" && az vm create -n $rg -g $rg -l $region --size $size --nics $nic --image $sys --admin-username $usr --admin-password $pas &
done
region="centralindia"
size="Standard_A0"
vnet="$region-oxy-vnet" && subnet="$region-oxy-subnet" && vm="$region-oxy" && nsg="$region-oxy-nsg" && nic="$region-nic" && rg="$region-oxy" && az vm create -n $rg -g $rg -l $region --size $size --nics $nic --image $sys --admin-username $usr --admin-password $pas
}
function ipCreate() {
JOBS_COUNTER=0
MAX_CHILDREN=100
MY_PID=$$
for region in $(cat /root/clouddrive/region.txt)
do
for i in {1..58}
do
JOBS_COUNTER=$((`ps ax -Ao ppid | grep $MY_PID | wc -l`))
while [ $JOBS_COUNTER -ge $MAX_CHILDREN ]
do
JOBS_COUNTER=$((`ps ax -Ao ppid | grep $MY_PID | wc -l`))
sleep 1's'
done
#
rg="$region-oxy" && az network public-ip create -g $rg -l $region -n $region-oxy-$i --allocation-method Dynamic &
#
done
done
echo Finishing children ...
# 
while [ $JOBS_COUNTER -gt 1 ]
do
JOBS_COUNTER=$((`ps ax -Ao ppid | grep $MY_PID | wc -l`))
echo Jobs counter: $JOBS_COUNTER
sleep 1's'
done
}
function ipConf() {
for region in $(cat /root/clouddrive/region.txt)
do
bash /root/clouddrive/ipconf.bash $region &
done
}
general
ipCreate
ipConf